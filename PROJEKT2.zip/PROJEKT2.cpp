#include <iostream>
#include <cstdlib>
using namespace std;

int main() {
    int Tab[100];
    int k = 0, m, liczba;

    // Wprowadzanie liczb do tablicy
    cout << "Wprowadz liczby: " << endl;
    cout << "Aby zakonczyc wpisywanie liczb, wpisz liczbe wieksza od 9" << endl;

    while (true) {
        cin >> liczba;
        if (liczba >= 10) {
            break; // P�tla ko�czy si�, gdy liczba jest >= 10
        }
        Tab[k++] = liczba; // Zapisujemy liczb� w tablicy
    }

    // Wprowadzamy warto�� m
    cout << "Wprowadz odleglosc (liczbe m): ";
    cin >> m;

    // Sprawdzamy, czy m jest wi�ksze ni� 0
    if (m <= 0) {
        cout << "Odleglosc m musi byc wieksza od 0." << endl;
        return 1; // Ko�czymy, je�li m nie jest poprawne
    }

    // Brute-force � por�wnujemy ka�d� liczb� z ka�d� inn�
    bool znalazlem = false;
    for (int w = 0; w < k; w++) {
        for (int s = w + 1; s < k; s++) {
            // Por�wnujemy ka�d� liczb� z ka�d� inn�, bez sprawdzania odleg�o�ci m
            if (Tab[w] == Tab[s]) {
                cout << Tab[s] << " ";
                znalazlem = true;
            }
        }
    }

    if (!znalazlem) {
        cout << "Brak elementow spelniajacych kryteria" << endl;
    }

    cout << endl;
    return 0;
}
