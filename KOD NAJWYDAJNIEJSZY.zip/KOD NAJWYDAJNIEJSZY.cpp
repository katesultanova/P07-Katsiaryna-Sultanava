#include <iostream>
#include <vector>
#include <set>
#include <unordered_map>
using namespace std;

int main() {

    vector<int> Tab;
    int m, liczba;

    // Wprowadzanie liczb do tablicy
    cout << "Wprowadz liczby: " << endl;
    cout << "Aby zakonczyc wpisywanie liczb, wpisz liczbe wieksza od 9" << endl;
    while (true) {
        cin >> liczba;
        if (liczba >= 10) {
            break; // Pętla kończy się, gdy liczba jest >= 10
        }
        Tab.push_back(liczba); // Dodajemy liczbę do wektora
    }

    // Wprowadzamy wartość m
    cout << "Wprowadz odleglosc (liczbe m): ";
    cin >> m;

    // Sprawdzamy, czy m jest większe niż 0
    if (m <= 0) {
        cout << "Odleglosc m musi byc wieksza od 0." << endl;
        return 1; // Kończymy, jeśli m nie jest poprawne
    }
  bool znalazlem = false;
    set<int> wypisane; // Zbiór do przechowywania już wypisanych liczb
    unordered_map<int, int> ostatnia_pozycja; // Mapa przechowująca ostatnią pozycję liczby

    // Przechodzimy przez tablicę
    for (int i = 0; i < Tab.size(); i++) {
        // Sprawdzamy, czy ta liczba już wystąpiła w odległości m
        if (ostatnia_pozycja.find(Tab[i]) != ostatnia_pozycja.end()) {
            int poprzednia_pozycja = ostatnia_pozycja[Tab[i]];

            // Jeśli odległość między poprzednią a obecną pozycją jest mniejsza lub równa m, wypisujemy liczbę
            if (i - poprzednia_pozycja <= m) {
                // Sprawdzamy, czy ta liczba już była wypisana
                if (wypisane.find(Tab[i]) == wypisane.end()) {
                    cout << Tab[i] << " ";
                    wypisane.insert(Tab[i]); // Dodajemy liczbę do zbioru
                    znalazlem = true;
                }
            }
        }

        // Zapisujemy bieżącą pozycję liczby w mapie
        ostatnia_pozycja[Tab[i]] = i;
    }

    if (!znalazlem) {
        cout << "Brak elementow spelniajacych kryteria" << endl;
    }


    return 0;
}
